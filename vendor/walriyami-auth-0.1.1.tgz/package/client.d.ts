export declare function SharedSignIn({ enabled, label, className, prefix }: {
    enabled: boolean;
    label?: string;
    className?: string;
    prefix?: string;
}): import("react").DetailedReactHTMLElement<{
    href: string;
    className: string | undefined;
}, HTMLElement> | null;
export declare function SharedSignOut({ global, prefix, headers, label }: {
    global?: boolean;
    prefix?: string;
    headers?: Record<string, string>;
    label?: string;
}): import("react").DetailedReactHTMLElement<import("react").HTMLAttributes<HTMLElement>, HTMLElement>;
