import { createElement, useState } from 'react';
export function SharedSignIn({ enabled, label = 'Sign in with Walriyami', className, prefix = '/api/sso' }) { return enabled ? createElement('a', { href: `${prefix}/login`, className }, label) : null; }
export function SharedSignOut({ global = false, prefix = '/api/sso', headers = {}, label = 'Sign out' }) {
    const [error, setError] = useState('');
    return createElement('div', null, createElement('button', { type: 'button', onClick: async () => { try {
            const response = await fetch(`${prefix}/logout`, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify({ global }) });
            const value = await response.json();
            if (!response.ok)
                throw new Error(value.error ?? 'Sign out failed.');
            location.assign(value.url);
        }
        catch (error) {
            setError(error.message);
        } } }, label), error ? createElement('p', { role: 'alert' }, error) : null);
}
