import { createRemoteJWKSet, jwtVerify } from 'jose';
import { createHash, randomBytes } from 'node:crypto';
export async function registerSso(app, options) {
    const prefix = options.prefix ?? '/api/sso', enabled = !!(options.issuer && options.clientId && options.clientSecret), secure = options.secureCookies ?? options.origin.startsWith('https:');
    app.get(`${prefix}/config`, () => ({ enabled }));
    if (!enabled)
        return;
    const stateCookie = secure ? '__Host-wal_sso_state' : 'wal_sso_state';
    if (options.failureRedirect && (!options.failureRedirect.startsWith('/') || new URL(options.failureRedirect, options.origin).origin !== new URL(options.origin).origin))
        throw new Error('Shared sign-in errors must redirect within the application.');
    app.addHook('onRequest', async (req) => { if (req.url.startsWith(prefix) && !['GET', 'HEAD', 'OPTIONS'].includes(req.method) && ((req.headers.origin && req.headers.origin !== options.origin) || req.headers['sec-fetch-site'] === 'cross-site'))
        throw Object.assign(new Error('Cross-origin sign-in request rejected.'), { statusCode: 403 }); });
    const issuer = options.issuer.replace(/\/$/, ''), redirectUri = `${options.origin}${prefix}/callback`;
    let discovery;
    async function discover() { if (discovery)
        return discovery; const r = await fetch(`${issuer}/.well-known/openid-configuration`, { signal: AbortSignal.timeout(10000) }); if (!r.ok)
        throw Object.assign(new Error('Shared sign-in is unavailable.'), { statusCode: 503 }); const value = await r.json(); if (value.issuer !== issuer)
        throw new Error('Identity provider issuer mismatch.'); discovery = value; return value; }
    async function begin(reply, linkUserId) { const d = await discover(), state = randomBytes(32).toString('base64url'), nonce = randomBytes(32).toString('base64url'), verifier = randomBytes(48).toString('base64url'); await options.adapter.saveFlow(state, { nonce, verifier, expires: Date.now() + 300000, linkUserId }); reply.setCookie(stateCookie, state, { path: '/', httpOnly: true, sameSite: 'lax', secure, maxAge: 300 }); const u = new URL(d.authorization_endpoint); for (const [k, v] of Object.entries({ client_id: options.clientId, redirect_uri: redirectUri, response_type: 'code', scope: 'openid profile email', state, nonce, code_challenge: createHash('sha256').update(verifier).digest('base64url'), code_challenge_method: 'S256', ...(linkUserId ? { prompt: 'login' } : {}) }))
        u.searchParams.set(k, v); return u.toString(); }
    app.get(`${prefix}/login`, async (_req, reply) => reply.redirect(await begin(reply)));
    app.post(`${prefix}/logout`, async (req, reply) => { if (!options.adapter.logout)
        throw Object.assign(new Error('Application logout adapter is not configured.'), { statusCode: 501 }); await options.adapter.logout(req, reply); const d = await discover(); if (req.body?.global && d.end_session_endpoint) {
        const url = new URL(d.end_session_endpoint);
        url.searchParams.set('client_id', options.clientId);
        url.searchParams.set('post_logout_redirect_uri', options.origin);
        return { url: url.toString() };
    } return { url: options.origin }; });
    app.post(`${prefix}/link`, async (req, reply) => { const password = req.body?.password; if (typeof password !== 'string' || !password)
        throw Object.assign(new Error('Re-enter your application password to link accounts.'), { statusCode: 400 }); const userId = await options.adapter.reauthenticate(req, password); return { url: await begin(reply, userId) }; });
    app.get(`${prefix}/callback`, { errorHandler: options.failureRedirect ? async (error, _req, reply) => { const status = error.statusCode; const url = new URL(options.failureRedirect, options.origin); url.searchParams.set('sso', status === 409 ? 'link-required' : status === 403 ? 'access-denied' : status === 400 ? 'expired' : 'unavailable'); reply.clearCookie(stateCookie, { path: '/' }); return reply.redirect(url.pathname + url.search); } : undefined }, async (req, reply) => { const q = req.query; const cookie = req.cookies?.[stateCookie]; if (!q.state || q.state !== cookie || !q.code)
        throw Object.assign(new Error('Invalid shared sign-in response.'), { statusCode: 400 }); const flow = await options.adapter.takeFlow(q.state); reply.clearCookie(stateCookie, { path: '/' }); if (!flow || flow.expires < Date.now())
        throw Object.assign(new Error('Shared sign-in expired. Try again.'), { statusCode: 400 }); const d = await discover(); const response = await fetch(d.token_endpoint, { method: 'POST', headers: { authorization: `Basic ${Buffer.from(`${encodeURIComponent(options.clientId)}:${encodeURIComponent(options.clientSecret)}`).toString('base64')}`, 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ grant_type: 'authorization_code', code: q.code, redirect_uri: redirectUri, code_verifier: flow.verifier }), signal: AbortSignal.timeout(10000) }); if (!response.ok)
        throw Object.assign(new Error('Shared sign-in was rejected.'), { statusCode: 401 }); const token = await response.json(); const { payload } = await jwtVerify(token.id_token, createRemoteJWKSet(new URL(d.jwks_uri)), { issuer, audience: options.clientId, algorithms: ['RS256', 'ES256'] }); if (payload.nonce !== flow.nonce || !payload.sub)
        throw Object.assign(new Error('Invalid shared identity.'), { statusCode: 401 }); let profile = payload; if (d.userinfo_endpoint && token.access_token) {
        const r = await fetch(d.userinfo_endpoint, { headers: { authorization: `Bearer ${token.access_token}` }, signal: AbortSignal.timeout(10000) });
        if (!r.ok)
            throw Object.assign(new Error('Shared identity profile unavailable.'), { statusCode: 401 });
        const info = await r.json();
        if (info.sub !== payload.sub)
            throw Object.assign(new Error('Shared identity subject mismatch.'), { statusCode: 401 });
        profile = { ...payload, ...info };
    } const identity = { issuer, subject: payload.sub, username: String(profile.preferred_username ?? ''), displayName: String(profile.name ?? profile.preferred_username ?? 'Member'), email: typeof profile.email === 'string' ? profile.email : undefined }; if (!await options.adapter.authorize(identity, token.id_token, token.access_token))
        throw Object.assign(new Error('You have not been granted access to this application.'), { statusCode: 403 }); let userId = await options.adapter.findAccount(identity); if (flow.linkUserId) {
        if (userId && userId !== flow.linkUserId)
            throw Object.assign(new Error('This identity is already linked to another account.'), { statusCode: 409 });
        await options.adapter.linkAccount(flow.linkUserId, identity);
        userId = flow.linkUserId;
    }
    else if (!userId) {
        userId = await options.adapter.createAccount(identity);
        await options.adapter.linkAccount(userId, identity);
    } await options.adapter.finish(userId, req, reply, identity); return reply.redirect('/'); });
}
export { createGrantClient, registerAppGrantGuard } from './guard.js';
