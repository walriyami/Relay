# Optional shared sign-in

`registerSso(app, options)` adds OIDC authorization-code/PKCE routes when issuer/client credentials are configured. Without them it exposes only an `enabled: false` capability response, leaving application authentication and public routes alone. Register `@fastify/cookie` first. Supply the account adapter to preserve the application's user model. Never link accounts by email: use the reauthenticated link route. `SharedSignIn` from `@walriyami/auth/client` is an optional React component.

Persist pending flows with single-use consumption. `authorize` must check current app grants. Revoked grants must also invalidate SSO-derived application sessions; retain independent app-local sessions. Keep existing logout local to the application unless a separate explicit global sign-out action is provided.
