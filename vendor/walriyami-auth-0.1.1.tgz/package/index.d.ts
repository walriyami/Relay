import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
export type SsoIdentity = {
    issuer: string;
    subject: string;
    username: string;
    displayName: string;
    email?: string;
};
export type SsoFlow = {
    verifier: string;
    nonce: string;
    expires: number;
    linkUserId?: string;
};
export type SsoAdapter = {
    saveFlow(state: string, flow: SsoFlow): void | Promise<void>;
    takeFlow(state: string): SsoFlow | undefined | Promise<SsoFlow | undefined>;
    authorize(identity: SsoIdentity, idToken: string, accessToken?: string): Promise<boolean>;
    findAccount(identity: SsoIdentity): string | undefined | Promise<string | undefined>;
    createAccount(identity: SsoIdentity): Promise<string>;
    linkAccount(userId: string, identity: SsoIdentity): void | Promise<void>;
    reauthenticate(req: FastifyRequest, password: string): Promise<string>;
    finish(userId: string, req: FastifyRequest, reply: FastifyReply, identity: SsoIdentity): void | Promise<void>;
    logout?(req: FastifyRequest, reply: FastifyReply): void | Promise<void>;
};
export type SsoOptions = {
    issuer?: string;
    clientId?: string;
    clientSecret?: string;
    origin: string;
    adapter: SsoAdapter;
    prefix?: string;
    secureCookies?: boolean;
    failureRedirect?: string;
};
export declare function registerSso(app: FastifyInstance, options: SsoOptions): Promise<void>;
export { createGrantClient, registerAppGrantGuard } from './guard.js';
