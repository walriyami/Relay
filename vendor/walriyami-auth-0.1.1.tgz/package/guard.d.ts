import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import type { SsoIdentity } from './index.js';
export declare function createGrantClient(config: {
    origin: string;
    projectId: string;
    token: string;
}): {
    issue: (_identity: SsoIdentity, idToken: string, accessToken?: string) => Promise<{
        allowed: boolean;
        administrator?: boolean;
    }>;
    check: (identity: SsoIdentity) => Promise<boolean>;
};
/** App-local sessions and public routes remain governed by the application's own rules. */
export declare function registerAppGrantGuard(app: FastifyInstance, options: {
    publicRoutes: string[];
    identity: (request: FastifyRequest) => SsoIdentity | undefined | Promise<SsoIdentity | undefined>;
    check: (identity: SsoIdentity) => Promise<boolean>;
    revoke: (request: FastifyRequest, reply: FastifyReply) => void | Promise<void>;
    cacheMs?: number;
}): void;
