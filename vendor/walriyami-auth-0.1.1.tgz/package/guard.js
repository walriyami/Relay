import { posix } from 'node:path';
export function createGrantClient(config) {
    async function request(path, body) { const response = await fetch(`${config.origin}/api/apps/${config.projectId}/grants/${path}`, { method: 'POST', headers: { authorization: `Bearer ${config.token}`, 'content-type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(5000) }); if (!response.ok)
        return { allowed: false, administrator: false }; return await response.json(); }
    return {
        issue: (_identity, idToken, accessToken) => request('issue', { idToken, accessToken }),
        check: async (identity) => (await request('check', { issuer: identity.issuer, subject: identity.subject })).allowed,
    };
}
/** App-local sessions and public routes remain governed by the application's own rules. */
export function registerAppGrantGuard(app, options) {
    const cache = new Map();
    app.addHook('onRequest', async (request, reply) => {
        let path;
        try {
            path = decodeURIComponent(request.url.split('?')[0]);
        }
        catch {
            throw Object.assign(new Error('Invalid route encoding.'), { statusCode: 400 });
        }
        path = posix.normalize(path);
        if (options.publicRoutes.some(p => p.endsWith('*') ? path.startsWith(p.slice(0, -1)) : path === p))
            return;
        const identity = await options.identity(request);
        if (!identity)
            return;
        const key = identity.issuer + '|' + identity.subject;
        let grant = cache.get(key);
        if (!grant || grant.expires < Date.now()) {
            grant = { allowed: await options.check(identity).catch(() => false), expires: Date.now() + Math.min(options.cacheMs ?? 10000, 30000) };
            if (cache.size >= 1000)
                cache.delete(cache.keys().next().value);
            cache.set(key, grant);
        }
        if (!grant.allowed) {
            await options.revoke(request, reply);
            throw Object.assign(new Error('Shared application access is unavailable or has been revoked.'), { statusCode: 403 });
        }
    });
}
